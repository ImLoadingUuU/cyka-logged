# Cyka-LOGGED v2.0
## I will not plan to pull to the original repo anymore, there's a lot of unstable features
A free and open-sourced authentication template was created. Created by [PlanetCloud/PlanetTheCloud](https://www.byet.net/index.php?/profile/528767-planetcloud/) for the MyOwnFreeHost community.

# Planned features:
- New multisite system
- Translation support
- Easy background customization
- ReCaptcha Support (very stable no scam)
- Customize confirm email page/after submit

# Discord
<a href="https://discord.gg/mmEWpnwB8D"><img src="https://discordapp.com/api/guilds/399429466566426635/widget.png?style=banner2" alt="Join our Discord Server" title="Planet Dev Network"></a>

# Contributions
All contributions are appreciated. If you want to contribute, please create a pull request.  
To report a bug/issue, kindly do so by opening a new issue.

# License
This project is licensed under the MIT License.
