<html>
    <head>
        <title>Something went wrong...</title>
    </head>
    <body>
        <h1>Error encountered</h1>
        <p>Sorry for the inconvinience. The system encountered an error.</p>
        <p>Don't worry, it's not your fault. Please try again later.</p>
        <p>If you need any assistance please contact our support team.</p>
        <p><a href="/">Go back to our website</a></p>
    </body>
</html>