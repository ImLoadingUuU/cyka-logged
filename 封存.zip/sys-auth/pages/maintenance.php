<html>
    <head>
        <title>Maintenance Mode</title>
    </head>
    <body>
        <h1>Maintenance Mode</h1>
        <p>Sorry for the inconvinience. The authentication system are currently under maintenance.</p>
        <p>We are working hard to finish this as soon as possible. If you need any assistance please contact our support team.</p>
        <p><a href="/">Go back to our website</a></p>
    </body>
</html>