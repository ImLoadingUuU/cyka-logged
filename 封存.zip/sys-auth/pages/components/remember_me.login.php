<input type="checkbox" name="remember" id="i_remember" class="filled-in chk-col-<?= config('branding.accent_color'); ?>">
<label for="i_remember"><?= __('Remember username') ?></label>